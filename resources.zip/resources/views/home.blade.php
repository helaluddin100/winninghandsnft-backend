@extends('master.master')

@section('content')
<div class="page-content">
    
</div>
@endsection
